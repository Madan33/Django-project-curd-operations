from django.urls import path
from . import views
from reg import views as user_view

urlpatterns = [
    path('', views.index, name='home'),
    path('login/', views.user_login, name='login'),
    path('signup/', views.user_signup, name='signup'),
    path('logout/', views.user_logout, name='logout'),


    # curd operations
    path('cud/',views.cud,name="cud"),
    path('add/',views.add,name="add"),
    #path("addrec/",views.addrec,name="addrec"),
    #path('delete/<int:id>/',views.delete,name="delete"),
    #path('update/<int:id>/',views.update,name="update"),
    #path('update/uprec/<int:id>/',views.uprec,name="uprec")




]
  






