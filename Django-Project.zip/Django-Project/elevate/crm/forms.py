
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from .models import teacher,student,depertment,Hotels,Booking,Rooms,student1,Tech
from django.forms.widgets import PasswordInput, TextInput
from django.contrib.auth.models import User
from django import forms


class CreateUserForm(UserCreationForm):
    class Meta:

        model = User
        fields = ['username', 'email', 'password1', 'password2']


class LoginForm(AuthenticationForm):

    username = forms.CharField(widget=TextInput())
    password = forms.CharField(widget=PasswordInput())



class ContactForm(forms.Form):
     class meta:
       model = teacher
       fields=['name','mail','phone','subject']
    

class studentform(forms.Form):
   class meta:
       model = student
       fields=['name','rollnumber','age','school','email','phone']

class depertmentform(forms.Form):
    class meta:
        model=depertment
        fields=['name','location','img']


class hotelform(forms.Form):
    class meta:
        models=Hotels
        fields=['name','location','state','country']


class roomform(forms.Form):
    class meta:
        models:Rooms
        fields=['room_type','capacity','price','roomno','hotel','status']




class student1form(forms.ModelForm):
    class meta:
        model= student1
        fields="__all__"


class TeacherForm(forms.ModelForm):
    class Meta:
        model = Tech
        fields = ['name', 'subject', 'image', 'experience']



from dataclasses import fields
from pyexpat import model
from django.forms import ModelForm
from django import forms
from .models import Employee
class EmployeeForm(ModelForm):
    class Meta:
        model=Employee
        fields='__all__'

        widgets={
            'name':forms.TextInput(attrs={'class':'form-control'}),
            'email':forms.TextInput(attrs={'class':'form-control'}),
            'password':forms.PasswordInput(attrs={'class':'form-control'},render_value=True)
        }