from crm.models import teacher, student,Hotels,Rooms, Booking,person1,student1,Person,Tech,depertment,Employee
from django.views.generic import ListView, CreateView, UpdateView, DeleteView,DetailView
from .forms import CreateUserForm, LoginForm,ContactForm,hotelform,roomform,TeacherForm,EmployeeForm
from .forms import ContactForm,studentform,depertmentform,student1form
from .models import teacher,student,depertment,Hotels,Book,depertment
from django.shortcuts import render, HttpResponse, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse,HttpResponseRedirect
from django.shortcuts import get_object_or_404
from django.shortcuts import render, redirect
from .tables import persontable,PersonTable
from django.contrib.auth.models import auth
from django_tables2 import SingleTableView
from django.views.generic  import ListView
from django.urls import reverse_lazy
from django.contrib import messages
from .tables import BookTable




def homepage(request):

    return render(request, 'student_reg/index.html')

#about contact form 
def contact(request):
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            try:
                teacher_instance = teacher.objects.create(
                    name=form.cleaned_data["name"],
                    mail=form.cleaned_data["mail"],
                    phone=form.cleaned_data["phone"],
                    subject=form.cleaned_data["subject"],
                )
                teacher_instance.save()
                return HttpResponse("Contact saved successfully!") 
            except Exception as e:
                print("Error saving Contact:", e)
                return HttpResponse(f"Error saving Contact: {e}")
    else:
        form = ContactForm()  

    context = {'form': form}  
    return render(request, 'crm/contact.html', context)
   


# getting data in admin into web pages
def posts(request):
    context = {}
    context['posts'] = teacher.objects.all()
    return render(request,'crm/posts.html', context)

#About student model
def student_file(request):
    form = studentform()
    if request.method == 'POST':
        form=studentform(request.POST)
        if form.is_valid():
            sd=form
            try:
                sf=student.objects.create(
                    name=sd.data['name'],
                    rollnumber=sd.data['rollnumber'],
                    age=sd.data['age'],
                    school=sd.data['school'],
                    email=sd.data['email'],
                    phone=sd.data['phone'],
                )
                sf.save()
                return HttpResponse("Student saved successfully!")
            except KeyError as e:
                print("KeyError:", e)
                return HttpResponse(f"Error saving student: {e}")
        else:
            print("Form is not valid, Please check your")
    else:
        form=studentform()
    context = {'student':form}
    return render(request, 'student.html', context=context)


#About depertment file
def dept_file(request):
    if request.method == 'POST':
        form = depertmentform(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return HttpResponse("Department saved successfully!")
    else:
        form = depertmentform()
    
    context = {'form': form}
    return render(request, 'crm/theme.html', context=context)



def room(request):
    form = hotelform()
    if request.method == 'POST':
        form=hotelform(request.POST)
        if form.is_valid():
            hd=form
            try:
                hf=Hotels.objects.create(
                    name=hd.data['name'],
                    location=hd.data['location'],
                    state=hd.data['state'],
                    country=hd.data['country'],
                    
                )
                hf.save()
                return HttpResponse("Hotel saved successfully!")
            
            except KeyError as e:
                
                print("KeyError:", e)
                return HttpResponse(f"Error saving Hotel List: {e}")
        else:
           
            print("Form is not valid, Please check your")
    else:
        form=studentform()
    context = {'Hotels':form}
    return render(request, 'crm/room_list.html', context=context)




def department_list(request):
    departments = depertment.objects.all()
    return render(request, 'department_list.html', {'departments': departments})



def show_room(request):
    context = {}
    context['show_room'] = Hotels.objects.all()
    return render(request,'crm/show_room.html', context)





def room1(request):
    form = roomform()
    if request.method == 'POST':
        form = roomform(request.POST)
        if form.is_valid():
            try:
                hotel_name = form.cleaned_data['hotel']
                hotel_instance = get_object_or_404(Hotels, name=hotel_name)
                rf = Rooms.objects.create(
                    room_type=form.cleaned_data['room_type'],
                    capacity=form.cleaned_data['capacity'],
                    price=form.cleaned_data['price'],
                    hotel=hotel_instance, 
                    roomno=form.cleaned_data['roomno'],
                    status=form.cleaned_data['status'],
                )
                rf.save()
                return HttpResponse("Rooms saved successfully!")
            
            except KeyError as e:
                print("KeyError:", e)
                return HttpResponse(f"Error saving Room List: {e}")
        else:
            print("Form is not valid. Please check your inputs.")
    else:
        form = roomform()
    
    context = {'form': form}
    return render(request, 'crm/room1_list.html', context=context)

       




def register(request):

    form = CreateUserForm()

    if request.method == "POST":

        form = CreateUserForm(request.POST)

        if form.is_valid():

            form.save()
            return redirect('/')  

        else:
            return render(request, 'student_reg/register.html', {'form': form})

   
    else:
        return render(request, 'student_reg/register.html', {'form': form})

            
        
#about login
def my_login(request):

    form = LoginForm()

    if request.method == 'POST':

        form = LoginForm(request, data=request.POST)

        if form.is_valid():

            username = request.POST.get('username')
            password = request.POST.get('password')

            user = authenticate(request, username=username, password=password)

            if user is not None:

                auth.login(request, user)

                return redirect("dashboard")


    context = {'loginform':form}

    return render(request, 'crm/my-login.html', context=context)






#about logout
def user_logout(request):

    auth.logout(request)

    return redirect("crm/dashboard.html")



@login_required(login_url="my-login")

def dashboard(request):

    return render(request, 'crm/dashboard.html')








#about Person Table to display 
def person_list(request):
    table = PersonTable(Person.objects.all())

    return render(request, "person_list.html", {
        "table": table
    })

#about to show  person data in admin panel
def person_data(request):
    context = {}
    context['person_data'] = person1.objects.all()
    return render(request,'person_data.html', context)



#Function based view by creating tables
def book_list(request):
    books = Book.objects.all()
    return render(request, 'crm/book_list_fun_view.html', {'books': books})


#classbased view
class booklistview(ListView):
    model=Book
    template_name='crm/book_list.html'
    context_object_name='books'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        table = BookTable(Book.objects.all())
        context['table'] = table
        return context




def teacher_list(request):
    teachers = Tech.objects.all()
    return render(request, 'teachers/teacher_list.html', {'teachers': teachers})

#def add_teacher(request):
    if request.method == 'POST':
        form = TeacherForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('teacher_list')  
    else:
        form = TeacherForm()
    return render(request, 'teachers/add_teacher.html', {'form': form})

#def edit_teacher(request, pk):
    teacher = get_object_or_404(Tech, pk=pk)
    if request.method == 'POST':
        form = TeacherForm(request.POST, instance=teacher)
        if form.is_valid():
            form.save()
            return redirect('teacher_list')
    else:
        form = TeacherForm(instance=teacher)
    return render(request, 'teachers/edit_teacher.html', {'form': form})

#def delete_teacher(request, pk):
    teacher = get_object_or_404(Tech, pk=pk)
    if request.method == 'POST':
        teacher.delete()
        return redirect('teacher_list')
    return render(request, 'teachers/confirm_delete.html', {'teacher': teacher})



#class IndexView(ListView):
    model = Blogs
    queryset = Blogs.objects.filter(status='published').all()
    template_name = 'blog/list_view.html'
    context_object_name = 'index_post_list'


# Create your views here.
def Home(request):
    if request.method == 'POST':
        form = EmployeeForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home') 
    else:
        form = EmployeeForm()
    data = Employee.objects.all()

    context = {
        'form': form,
        'data': data,
    }
    return render(request, 'employee/index.html', context)


def delete_record(request, pk):
    teacher = get_object_or_404(Employee, pk=pk)
    if request.method == 'POST':
        teacher.delete()
        return redirect('employee_list')
    return render(request, 'employee/base.html', {'teacher': teacher})
# Delete View
#def delete_record(request, id):
    employee = get_object_or_404(Employee, pk=id)
    employee.delete()
    return redirect('employee_list') 
    

# Update View
def Update_Record(request,id):
    if request.method=='POST':
        data=Employee.objects.get(pk=id)
        form=EmployeeForm(request.POST,instance=data)
        if form.is_valid():
            form.save()
    else:

        data=Employee.objects.get(pk=id)
        form=EmployeeForm(instance=data)
    context={
        'form':form,
    }
    return render (request,'employee/update.html',context)




# views.py
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import viewsets
from rest_framework import status
from .comment import Comment
from .Serializers import *
from .models import *



#Model serializers
@api_view(["GET","POST"])
def ramana(request):
    queryset = rama.objects.all()
    serializer = ramaSerializers(queryset, many=True)
    return Response({'Status': 200, "payload": serializer.data})


@api_view(["GET","POST"])
def hotl(request):
    queryset=Hotels.objects.all()
    serializers_class=hotelseralizers(queryset,many=True)
    return Response ({'payload':serializers_class.data})

#simple serializers
#@api_view(["GET"])
#def raghu(request):
   # comment_obj = Comment('maddy@gmail.com','hi how are you')
    #serializer_class = CommentSerializer(comment_obj)
    #return Response(serializer_class.data)

#class based view in django-restframework
class listproduct(APIView):

    def get(self, request):
        queryset = product.objects.all()
        serializer_class = productseralizers(queryset, many=True)
        return Response(serializer_class.data)


class productdetailedview(APIView):
    def get(self, request,pid):
        queryset = product.objects.filter(product_id=pid)
        serializer_class = productseralizers(queryset, many=True)
        return Response(serializer_class.data)
    

    def put(self, request,pid):
        product_obj=product.objects.get(product_id=pid)
        serializer_obj=productseralizers(product_obj,data=request.data)
        if serializer_obj.is_valid(raise_exception=True):
            product_saved=serializer_obj.save()
            return Response({"Success":"Product  '{}' Updated successfully".format(product_saved.name)})
        return Response(serializer_obj.errors, status=status.HTTP_400_BAD_REQUEST)


    def delete(self,request,pid):
        product_obj=product.objects.filter(product_id=pid).delete
        return Response(status = status.HTTP_200_OK)
    

    def post(self, request,pid):
        serializer_obj=productseralizers(data=request.data)
        if serializer_obj.is_valid(raise_exception=True):
            product_saved=serializer_obj.save()
            return Response({"Success":"Product  '{}' created suceffually".format(product_saved.name)})
        return Response(serializer_obj.errors, status=status.HTTP_400_BAD_REQUEST)


#Mixins
from rest_framework import mixins
from rest_framework import generics


class listproductMixins(mixins.ListModelMixin,generics.GenericAPIView):
    queryset=product.objects.all()
    serializer_class=productseralizers

    def get(self,request,*args ,**kwargs):
        return self.list(request,*args,**kwargs)
    
class DetailedproductMixins(mixins.RetrieveModelMixin,mixins.CreateModelMixin,mixins.DestroyModelMixin,mixins.UpdateModelMixin,generics.GenericAPIView):
    queryset=product.objects.filter()
    serializer_class=productseralizers

    def get(self,request,*args ,**kwargs):
        return self.retrieve(request,*args,**kwargs)
    
    def put(self,request,*args ,**kwargs):
        return self.update(request,*args,**kwargs)
    
    
    def post(self,request,*args ,**kwargs):
        return self.create(request,*args,**kwargs)
    
    
    def delete(self,request,*args ,**kwargs):
        return self.destroy(request,*args,**kwargs)

#Generics
class listproductgeneric(generics.ListAPIView):
    queryset=product.objects.all()
    serializer_class=productseralizers


    
class detailproductgeneric(generics.RetrieveAPIView,generics.UpdateAPIView,generics.DestroyAPIView):
    queryset=product.objects.all()
    serializer_class=productseralizers

        


class specialproductgeneric(generics.ListCreateAPIView,generics.RetrieveUpdateDestroyAPIView):
    queryset=product.objects.all()
    serializer_class=productseralizers


#viewset's
class productviewsets(viewsets.ModelViewSet):
    queryset=product.objects.all()
    serializer_class=productseralizers


#using 


class hoteldetailedview(APIView):
    def get(self, request):
        queryset = Hotels.objects.filter()
        serializer_class = hotelseralizers(queryset, many=True)
        return Response(serializer_class.data)


