from rest_framework import serializers
from .models import *


class ramaSerializers(serializers.ModelSerializer):
    class Meta:
        model=rama
        fields=['name','age','place']



class productseralizers(serializers.ModelSerializer):
    class Meta:
        model=product
        fields='__all__'
    
class hotelseralizers(serializers.ModelSerializer):
    class Meta:
        model=Hotels
        fields='__all__'