from django.urls import path
from . import views
from .views import booklistview,listproduct,productdetailedview,productviewsets,hoteldetailedview
from rest_framework.routers import DefaultRouter,SimpleRouter

router=DefaultRouter()
router.register(
    'productviewsets',productviewsets,basename='productviewsets'
)


app_name="crm"

urlpatterns = [

    path('', views.homepage, name="homepage"),
    
    path('register', views.register, name="register"),

    path('my-login', views.my_login, name="my-login"),

    path('dashboard', views.dashboard, name="dashboard"),

    path('user-logout', views.user_logout, name="user-logout"),

    path('contact/', views.contact, name="contact"),

    path('posts',views.posts,name='posts'),

    path('student_file',views.student_file, name="student_file"),

    path('dept_file', views.dept_file, name='dept_file'),

    path('department_list/',views.department_list, name='department_list'),

    path('rooms', views.room, name='rooms'),

    path('room1', views.room1 , name='room1'),
    
    path('show_room', views.show_room, name='show_room'),


    #path('listview/',listview.as_view(),name='listview'),

    #path('person-table/', PersonTableView.as_view(), name='person_table'),

    path('person_list',views.person_list,name='person_list'),

    path('person_data',views.person_data,name='person_data'),

    path('books/',booklistview.as_view(),name='books'),

    path('book_list/',views.book_list,name='book_list'),
    path('hotl/',views.hotl,name='hotl'),
   
    path('teacher_list/', views.teacher_list, name='teacher_list'),
    #path('teacher/<int:pk>/edit/', views.edit_teacher, name='edit_teacher'),
    #path('teacher/<int:pk>/delete/', views.delete_teacher, name='delete_teacher'),
    path('departments_list/',views.department_list,name='departments_list'),
    path('home/',views.Home,name='home'),
    path('delete/<int:id>',views.delete_record,name='delete'),
    path('<int:id>',views.Update_Record,name='update'),
#curd operations
    path('ramana/',views.ramana,name='ramana'),
    #path('raghu/',views.raghu,name='raghu')
    path('listproduct/',listproduct.as_view(),name='listproduct'),
    path('productdetailedview/<int:pid>',productdetailedview.as_view(),name='productdetailedview'),
   #Mixin's
    path('listproductMixins/',views.listproductMixins.as_view(),name='listproductMixins'),
    path('DetailedproductMixins/<int:pk>/',views.DetailedproductMixins.as_view(),name='DetailedproductMixins'),
  #generic
    path('listproductgeneric/',views.listproductgeneric.as_view(),name='listproductgeneric'),
    path('detailproductgeneric/<int:pk>/',views.detailproductgeneric.as_view(),name='detailproductgeneric'),
    path('specialproductgeneric/<int:pk>/',views.specialproductgeneric.as_view(),name='specialproductgeneric'),

    #viewsets
    path("hoteldetailedview/",hoteldetailedview.as_view,name='hoteldetailedview')



  








]+router.urls



     
   





    










