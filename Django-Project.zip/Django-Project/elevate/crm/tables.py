from django_tables2 import tables
from .models import Person,person1,Book,Tech


class persontable(tables.Table):
    class Meta:
        model=Person
        table_name="django_tables2/bootstrap5.html"
        fields=['first_name','family_name']

class PersonTable(tables.Table):
    class Meta:
        model = person1
        sequence = ("last_name", "first_name", "birth_date", )
        exclude = ("user", )




class BookTable(tables.Table):
    class Meta:
        model = Book
        template_name = "django_tables2/bootstrap4.html"  
        fields = ("title", "author", "publication_date") 



