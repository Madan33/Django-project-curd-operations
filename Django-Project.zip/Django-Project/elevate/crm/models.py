from django.db import models
from django.utils import timezone
from django.forms import ModelForm
from django.contrib.auth.models import User
from django.contrib.auth import get_user_model

# Create your models here.
class teacher(models.Model):
    name=models.CharField(max_length=250, help_text="Name", blank=False)
    mail=models.CharField(max_length=250, help_text="Mail", blank=False)
    phone=models.IntegerField(default=0,help_text=" Phone", blank=False) 
    subject=models.CharField(max_length=200, help_text="Subject", blank=True)

class depertment(models.Model):
    name=models.CharField(max_length=200, help_text="name",null=False)
    location=models.CharField(max_length=200,help_text="location", null=False)
    img= models.ImageField(default='image.jpg',upload_to='images', height_field=None, width_field=None, max_length=100)

    

class student(models.Model):
    name=models.CharField(max_length=100, help_text="student Name", blank=False)
    rollnumber=models.CharField(max_length=100, help_text="student Rollnumber", blank=False)
    age=models.IntegerField()
    school=models.CharField(max_length=100, help_text="student Email", blank=False)
    email=models.EmailField(max_length=100,help_text="student phone", blank=False)
    phone=models.IntegerField()    

    def __str__(self):
        return self.name



class Hotels(models.Model):

    #h_id,h_name,owner ,location,rooms
    name = models.CharField(max_length=30,default="")
    location = models.CharField(max_length=50)
    state = models.CharField(max_length=50,default="")
    country = models.CharField(max_length=50,default="india")
    def __str__(self):
        return self.name


class Rooms(models.Model):
    ROOM_STATUS = ( 
         ('AC'),
         ('NON_AC'),
         ("PREMIUM"),
         ("DELUX"),
    )

    #type,no_of_rooms,capacity,prices,Hotel
    room_type = models.CharField(max_length=50)
    capacity = models.IntegerField()
    price = models.IntegerField()
    hotel = models.ForeignKey(Hotels, on_delete = models.CASCADE)
    status = models.CharField(max_length = 15)
    roomno = models.IntegerField()
    def __str__(self):
        return self.hotel.name

class Booking(models.Model):

    check_in = models.DateField(auto_now =False)
    check_out = models.DateField()
    room = models.ForeignKey(Rooms, on_delete = models.CASCADE)
    guest = models.ForeignKey(User, on_delete= models.CASCADE)
    
    booking_id = models.CharField(max_length=100,default="null")
    def __str__(self):
        return self.guest.username


class Person(models.Model):
    first_name = models.CharField(max_length=200)
    last_name = models.CharField(max_length=200)




class person1(models.Model):
    first_name = models.CharField(max_length=200)
    last_name = models.CharField(max_length=200)
    user = models.ForeignKey(get_user_model(), null=True, on_delete=models.CASCADE)
    birth_date = models.DateField()



class student1(models.Model):
    name=models.CharField(max_length=100,help_text="name",blank=False)
    email=models.CharField(max_length=100,help_text='email',blank=False)
    phone=models.CharField(max_length=100,help_text='phone',blank=False)
    roll=models.CharField(max_length=100,help_text='roll',blank=False)
    adress=models.CharField(max_length=100,help_text='adress',blank=False)
    





class Book(models.Model):
    title = models.CharField(max_length=100)
    author = models.CharField(max_length=100)
    publication_date = models.DateField()

    def __str__(self):
        return self.title


class Tech(models.Model):
    name = models.CharField(max_length=100)
    subject = models.CharField(max_length=100)
    image = models.ImageField(upload_to='teachers/images/')
    experience = models.PositiveIntegerField()

    def __str__(self):
        return self.name
    

class Employee(models.Model):
    name=models.CharField(max_length=25,null=True)
    email=models.EmailField(max_length=60,null=True)
    password=models.CharField(max_length=12,null=True)

    def __str__(self) :
        return self.name
    


class rama(models.Model):
    name=models.CharField(max_length=100,help_text='Name',blank=False)
    age=models.IntegerField()
    place=models.CharField(max_length=100,help_text="place",blank=False)


class ProductCategory(models.Model):
    category_name=models.CharField(max_length=30,help_text="category_name",blank=False)
    category_id=models.PositiveBigIntegerField()
    class Meta:
        verbose_name_plural = 'ProductCategory'


class product(models.Model):
    category_name=models.ForeignKey(ProductCategory,related_name='ProductCategory',on_delete=models.CASCADE)
    product_id=models.PositiveBigIntegerField()
    name=models.CharField(max_length=30,help_text="Name",blank=False)
    cost=models.DecimalField(decimal_places=2,max_digits=6)
    date=models.DateField()
    description=models.TextField()

    class Meta:
        verbose_name_plural = 'product'