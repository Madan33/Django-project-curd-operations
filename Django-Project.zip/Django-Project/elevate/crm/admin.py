from django.contrib import admin
from .models import teacher,student,depertment, Hotels,Rooms,Booking,person1,student1,Book,Tech,Employee,rama,product,ProductCategory



class productadmin(admin.ModelAdmin):
    list_display=('name','mail','phone','subject')

class studentadmin(admin.ModelAdmin):
    list_display=['name','email','rollnumber','school','phone','age']

class student1admin(admin.ModelAdmin):
    list_display=['name','emial','phone','roll','adress']

class depertmentadmin(admin.ModelAdmin):
    list_display=['name','location','img']


class Hotelsadmin(admin.ModelAdmin):
    list_display=['name','location','state','country']


class person1admin(admin.ModelAdmin):
    list_display=['first_name','last_name','birth_date']


class roomadmin(admin.ModelAdmin):
    list_display=['room_type','capacity','price','hotel','status','roomno']


class bookingadmin(admin.ModelAdmin):
    list_display=['check_in','check_out','room','guest','booking_id']


class booksadmin(admin.ModelAdmin):
    list_display=['title','author','publication_date']


class techadmin(admin.ModelAdmin):
    list_display=['name','subject','image','experience']

class employeeadmin(admin.ModelAdmin):
    list_display=['name','email','password']

class ramadamin(admin.ModelAdmin):
    list_display=['name','age','place']


class productcatagoryadmin(admin.ModelAdmin):
    list_display=['category_name','category_id']

class product2admin(admin.ModelAdmin):
    def house_label(self, obj):
        return obj.category_name.category_name
    list_display=['category_name','product_id','name','cost','date','description']


admin.site.register(rama,ramadamin)
admin.site.register(ProductCategory,productcatagoryadmin)
admin.site.register(product,product2admin)
    
admin.site.register(teacher,productadmin)
admin.site.register(person1,person1admin)
admin.site.register(student1)
admin.site.register(Tech,techadmin)
admin.site.register(student,studentadmin)
admin.site.register(depertment,depertmentadmin)
admin.site.register(Hotels,Hotelsadmin)
admin.site.register(Rooms,roomadmin)
admin.site.register(Booking,bookingadmin)
admin.site.register(Book,booksadmin)
