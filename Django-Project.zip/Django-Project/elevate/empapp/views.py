from django.shortcuts import render,redirect
from django_tables2 import SingleTableView
from django.views.generic  import ListView
from empapp.models import emptable
from .tables import  employeetable

# Create your views here.
def empfun(request):
    return render(request,'viewpage.html')

def add_table(request):
    if request.method=='POST':
        ename=request.POST['empname']
        esal=request.POST['sal']
        contact=request.POST['num']
        empmail=request.POST['mail']
        emp=emptable(name=ename,salary=esal,contact_no=contact,email=empmail)
        emp.save()
        return redirect('showemp')
    
def showemp(request):
    emp=emptable.objects.all()
    return render(request,'showemployee.html',{'employee':emp})

def editpage(request,id):
    em=emptable.objects.get(id=id)
    return render(request,'edit.html',{'emplo':em})

def edit_emp(request,id):
    if request.method=='POST':
        em=emptable.objects.get(id=id)
        em.name=request.POST['empname']
        em.salary=request.POST['sal']
        em.contact_no=request.POST['num']
        em.email=request.POST['mail']
        em.save()
        return redirect(showemp)
    return render(request,'edit.html')

def delete_emp(request,id):
    emp=emptable.objects.get(id=id)
    emp.delete()
    return redirect('showemp')

#creating table
class listview(SingleTableView):
    model = emptable
    table_object_name='name'
    template_name='person_list.html'

    
def person_table(request):
    context = {}
    context['person_table'] = emptable.objects.all()
    return render(request,'person_data.html', context)
