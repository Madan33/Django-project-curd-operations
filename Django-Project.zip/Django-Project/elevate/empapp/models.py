from django.db import models

# Create your models here.
class emptable(models.Model):
    name=models.CharField(max_length=255)
    salary=models.IntegerField()
    contact_no=models.CharField(max_length=255)
    email=models.EmailField(max_length=255)

